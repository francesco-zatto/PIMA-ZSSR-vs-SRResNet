import torch
from torch.utils.data import Dataset
from data.preprocessing import SRPreprocessingStrategy
from abc import ABC

class AbstractSRDataset(Dataset, ABC):
    """
    Generic SISR Dataset that delegate preprocessing operations to a SRPreprocessingStrategy.
    """
    def __init__(self, root_dir: str, scale_factor: float, strategy: SRPreprocessingStrategy, ext: str):
        self.scale_factor = self.curr_s_i = scale_factor
        self.strategy = strategy

        self.strategy.prepare(root_dir, ext)

    def __len__(self) -> int:
        return len(self.strategy)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self._check(self.strategy.sample(idx, self.curr_s_i))

    def add_image(self, image: torch.Tensor) -> None:
        """
        Add to the dataset the new image, using the preprocessing strategy.
        """
        new_pairs = self.strategy.update([image])
    
    def _check(self, item: tuple[torch.Tensor, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Apply final check to LR and HR images, i.e. clamping them between 0.0 and 1.0.
        """
        lr_img, hr_img = item
        return torch.clamp(lr_img, 0.0, 1.0), torch.clamp(hr_img, 0.0, 1.0)
    

class Urban100Dataset(AbstractSRDataset):
    # TODO their root_dir should be a constant for ResNet and a given dir for ZSSR depending on the test image
    def __init__(self, root_dir: str, scale_factor: float, strategy: SRPreprocessingStrategy):
        super().__init__(root_dir, scale_factor, strategy, ext="*.png")

class BSD100Dataset(AbstractSRDataset):
    def __init__(self, root_dir: str, scale_factor: float, strategy: SRPreprocessingStrategy):
        super().__init__(root_dir, scale_factor, strategy, ext="*.png")

# for training ResNet
class COCODataset(AbstractSRDataset):
    def __init__(self, root_dir: str, scale_factor: float, strategy: SRPreprocessingStrategy):
        super().__init__(root_dir, scale_factor, strategy, ext="*.jpg")